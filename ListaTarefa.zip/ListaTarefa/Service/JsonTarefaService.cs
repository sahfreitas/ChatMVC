using System.Text.Encodings.Web;
using System.Text.Json;
using ListaTarefa.Models;

namespace ListaTarefa.Services;

public class TarefaRepository
{
    private readonly string _caminho;
    private readonly object _trava = new();

    private static readonly JsonSerializerOptions _opcoes = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    public TarefaRepository(IWebHostEnvironment env)
    {
        var pasta = Path.Combine(env.ContentRootPath, "Data");
        Directory.CreateDirectory(pasta);
        _caminho = Path.Combine(pasta, "tarefas.json");
    }

    public List<Tarefa> ListarTodas()
    {
        lock (_trava) { return Carregar(); }
    }

    public Tarefa? BuscarPorId(int id)
    {
        lock (_trava) { return Carregar().FirstOrDefault(t => t.Id == id); }
    }

    public Tarefa Criar(Tarefa nova)
    {
        lock (_trava)
        {
            var tarefas = Carregar();
            nova.Id = tarefas.Count == 0 ? 1 : tarefas.Max(t => t.Id) + 1;
            tarefas.Add(nova);
            Salvar(tarefas);
            return nova;
        }
    }

    public bool Atualizar(int id, Tarefa dados)
    {
        lock (_trava)
        {
            var tarefas = Carregar();
            var tarefa = tarefas.FirstOrDefault(t => t.Id == id);
            if (tarefa == null) return false;

            tarefa.Titulo = dados.Titulo;
            tarefa.Descricao = dados.Descricao;
            tarefa.Concluida = dados.Concluida;
            Salvar(tarefas);
            return true;
        }
    }

    public bool Apagar(int id)
    {
        lock (_trava)
        {
            var tarefas = Carregar();
            var removidas = tarefas.RemoveAll(t => t.Id == id);
            if (removidas == 0) return false;

            Salvar(tarefas);
            return true;
        }
    }

    private List<Tarefa> Carregar()
    {
        if (!File.Exists(_caminho)) return new List<Tarefa>();

        var json = File.ReadAllText(_caminho);
        if (string.IsNullOrWhiteSpace(json)) return new List<Tarefa>();

        return JsonSerializer.Deserialize<List<Tarefa>>(json, _opcoes) ?? new List<Tarefa>();
    }

    private void Salvar(List<Tarefa> tarefas)
    {
        File.WriteAllText(_caminho, JsonSerializer.Serialize(tarefas, _opcoes));
    }
}