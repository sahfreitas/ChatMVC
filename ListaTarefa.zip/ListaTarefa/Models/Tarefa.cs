using System.ComponentModel.DataAnnotations;

namespace ListaTarefa.Models;

public class Tarefa
{
    public int Id { get; set; }

    [Required(ErrorMessage = "O título é obrigatório.")]
    public string Titulo { get; set; } = "";

    public string? Descricao { get; set; }

    public bool Concluida { get; set; }
}