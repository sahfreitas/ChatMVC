using ListaTarefa.Models;
using ListaTarefa.Services;
using Microsoft.AspNetCore.Mvc;

namespace ListaTarefa.Controllers;

[ApiController]
[Route("api/tarefas")]
public class TarefasController : ControllerBase
{
    private readonly TarefaRepository _repo;

    public TarefasController(TarefaRepository repo)
    {
        _repo = repo;
    }

    [HttpGet]
    public IActionResult Get()
    {
        return Ok(_repo.ListarTodas());
    }

    [HttpGet("{id}")]
    public IActionResult Get(int id)
    {
        var tarefa = _repo.BuscarPorId(id);
        if (tarefa == null) return NotFound();

        return Ok(tarefa);
    }

    [HttpPost]
    public IActionResult Post(Tarefa tarefa)
    {
        var criada = _repo.Criar(tarefa);
        return CreatedAtAction(nameof(Get), new { id = criada.Id }, criada);
    }

    [HttpPut("{id}")]
    public IActionResult Put(int id, Tarefa tarefa)
    {
        if (!_repo.Atualizar(id, tarefa)) return NotFound();

        return Ok(_repo.BuscarPorId(id));
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        if (!_repo.Apagar(id)) return NotFound();

        return NoContent();
    }
}