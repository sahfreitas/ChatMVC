using System.ComponentModel.DataAnnotations;

namespace ChatMVC.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Informe o usuário.")]
        public string UserName { get; set; } = "";

        [Required(ErrorMessage = "Informe a senha.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";
    }
}
