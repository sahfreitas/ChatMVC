namespace ChatMVC.Models
{
    public class Sala
    {
        public string RoomName { get; set; }
        public List<string> Participantes { get; set; } = new();
        public List<Message> Messages { get; set; } = new();
    }
}