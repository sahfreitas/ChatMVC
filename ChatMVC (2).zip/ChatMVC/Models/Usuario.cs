namespace ChatMVC.Models
{
    public class Usuario
    {
        public string UserName { get; set; }
        public string Nome { get; set; }
        public string Password { get; set; }
        public string Situacao { get; set; } // "Ativo" ou "Inativo"
    }
}