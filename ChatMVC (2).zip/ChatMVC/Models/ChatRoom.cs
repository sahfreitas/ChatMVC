namespace ChatMVC.Models
{
    // Representa uma "conversa": a sala, quem já participou dela
    // e o histórico de mensagens. É essa estrutura que é gravada
    // no Json do lado do servidor (Data/Conversas.json).
    public class ChatRoom
    {
        public string RoomName { get; set; } = "";

        // Só quem está nesta lista pode ver/enviar mensagens na sala.
        public List<string> Participants { get; set; } = new();

        public List<Message> Messages { get; set; } = new();
    }
}
