using Microsoft.AspNetCore.Mvc;
using ChatMVC.Services;

namespace ChatMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly JsonChatService _chatService;

        public AccountController(JsonChatService chatService)
        {
            _chatService = chatService;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string userName, string password)
        {
            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
            {
                Response.StatusCode = StatusCodes.Status400BadRequest;
                ViewBag.Erro = "Preencha usuário e senha.";
                return View();
            }

            var usuario = _chatService.BuscarUsuario(userName, password);

            if (usuario == null)
            {
                Response.StatusCode = StatusCodes.Status401Unauthorized;
                ViewBag.Erro = "Usuário ou senha inválidos.";
                return View();
            }

            if (usuario.Situacao != "Ativo")
            {
                Response.StatusCode = StatusCodes.Status403Forbidden;
                ViewBag.Erro = "Usuário inativo. Procure o administrador.";
                return View();
            }

            // Session controla o login durante a navegação
            HttpContext.Session.SetString("UserName", usuario.UserName);

            return RedirectToAction("Index", "Chat");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}