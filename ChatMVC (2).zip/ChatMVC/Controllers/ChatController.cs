using Microsoft.AspNetCore.Mvc;
using ChatMVC.Models;
using ChatMVC.Services;

namespace ChatMVC.Controllers
{
    public class ChatController : Controller
    {
        private readonly JsonChatService _chatService;

        public ChatController(JsonChatService chatService)
        {
            _chatService = chatService;
        }

        public IActionResult Index()
        {
            var userName = HttpContext.Session.GetString("UserName");
            if (userName == null) return RedirectToAction("Login", "Account");

            ViewBag.UserName = userName;
            return View();
        }

        [HttpPost]
        public IActionResult Enter(string roomName)
        {
            var userName = HttpContext.Session.GetString("UserName");
            if (userName == null) return RedirectToAction("Login", "Account");

            if (string.IsNullOrWhiteSpace(roomName))
            {
                Response.StatusCode = StatusCodes.Status400BadRequest;
                ViewBag.Erro = "Informe o nome da sala.";
                ViewBag.UserName = userName;
                return View("Index");
            }

            _chatService.EntrarNaSala(roomName, userName);

            return RedirectToAction("Room", new { roomName });
        }

        public IActionResult Room(string roomName)
        {
            var userName = HttpContext.Session.GetString("UserName");
            if (userName == null) return RedirectToAction("Login", "Account");

            if (!_chatService.Participa(roomName, userName))
            {
                return StatusCode(StatusCodes.Status403Forbidden, "Você não participa desta sala.");
            }

            var model = new ChatViewModel
            {
                UserName = userName,
                RoomName = roomName,
                Messages = _chatService.ObterHistorico(roomName)
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult SendMessage(ChatViewModel model)
        {
            var userName = HttpContext.Session.GetString("UserName");
            if (userName == null) return RedirectToAction("Login", "Account");

            if (!_chatService.Participa(model.RoomName, userName))
            {
                return StatusCode(StatusCodes.Status403Forbidden, "Você não participa desta sala.");
            }

            if (string.IsNullOrWhiteSpace(model.MessageText))
            {
                Response.StatusCode = StatusCodes.Status400BadRequest;
                ViewBag.Erro = "A mensagem não pode ser vazia.";
                model.UserName = userName;
                model.Messages = _chatService.ObterHistorico(model.RoomName);
                return View("Room", model);
            }

            var msg = new Message
            {
                UserName = userName,
                RoomName = model.RoomName,
                Text = model.MessageText
            };

            _chatService.SalvarMensagem(msg);

            return RedirectToAction("Room", new { roomName = model.RoomName });
        }
    }
}