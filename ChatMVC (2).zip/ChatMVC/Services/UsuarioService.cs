using System.Text.Json;
using ChatMVC.Models;

namespace ChatMVC.Services
{
    // Lê a lista de usuários autorizados a usar o chat a partir de
    // um Json gravado numa pasta do servidor (Data/UsuariosChat.json).
    // O cadastro é feito diretamente no arquivo (fora da aplicação),
    // como pede o enunciado: "usuários que podem utilizar deverão
    // estar previamente cadastrados em um Json".
    public class UsuarioService
    {
        private readonly string _filePath;
        private readonly object _lock = new();

        public UsuarioService()
        {
            _filePath = Path.Combine(
                Directory.GetCurrentDirectory(),
                "Data",
                "UsuariosChat.json");

            if (!File.Exists(_filePath))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_filePath)!);

                // Usuários de exemplo, apenas para o arquivo não nascer vazio.
                var usuariosSeed = new List<Usuario>
                {
                    new Usuario { UserName = "ana",   Password = "123456" },
                    new Usuario { UserName = "bruno", Password = "123456" }
                };

                File.WriteAllText(
                    _filePath,
                    JsonSerializer.Serialize(usuariosSeed, new JsonSerializerOptions { WriteIndented = true }));
            }
        }

        public bool ValidarCredenciais(string userName, string password)
        {
            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
                return false;

            var usuarios = CarregarUsuarios();

            return usuarios.Any(u =>
                string.Equals(u.UserName, userName, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);
        }

        private List<Usuario> CarregarUsuarios()
        {
            lock (_lock)
            {
                var json = File.ReadAllText(_filePath);

                if (string.IsNullOrWhiteSpace(json))
                    return new List<Usuario>();

                return JsonSerializer.Deserialize<List<Usuario>>(json) ?? new List<Usuario>();
            }
        }
    }
}
