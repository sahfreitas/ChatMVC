using System.Text.Json;
using ChatMVC.Models;

namespace ChatMVC.Services
{
    public class JsonChatService
    {
        private readonly string _usuariosPath;
        private readonly string _conversasPath;

        public JsonChatService()
        {
            var pastaData = Path.Combine(Directory.GetCurrentDirectory(), "Data");
            Directory.CreateDirectory(pastaData);

            _usuariosPath = Path.Combine(pastaData, "UsuariosChat.json");
            _conversasPath = Path.Combine(pastaData, "Conversas.json");

            if (!File.Exists(_usuariosPath))
            {
                var usuarios = new List<Usuario>
                {
                    new Usuario { UserName = "ana", Nome = "Ana Souza", Password = "123456", Situacao = "Ativo" },
                    new Usuario { UserName = "bruno", Nome = "Bruno Lima", Password = "123456", Situacao = "Inativo" }
                };
                File.WriteAllText(_usuariosPath, JsonSerializer.Serialize(usuarios, new JsonSerializerOptions { WriteIndented = true }));
            }

            if (!File.Exists(_conversasPath))
            {
                File.WriteAllText(_conversasPath, "[]");
            }
        }

        // ---------- LOGIN ----------

        public Usuario BuscarUsuario(string userName, string password)
        {
            var json = File.ReadAllText(_usuariosPath);
            var usuarios = JsonSerializer.Deserialize<List<Usuario>>(json) ?? new List<Usuario>();

            return usuarios.FirstOrDefault(u =>
                u.UserName.Equals(userName, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);
        }

        // ---------- CONVERSAS ----------

        private List<Sala> CarregarSalas()
        {
            var json = File.ReadAllText(_conversasPath);
            if (string.IsNullOrWhiteSpace(json)) return new List<Sala>();
            return JsonSerializer.Deserialize<List<Sala>>(json) ?? new List<Sala>();
        }

        private void SalvarSalas(List<Sala> salas)
        {
            var json = JsonSerializer.Serialize(salas, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_conversasPath, json);
        }

        public void EntrarNaSala(string roomName, string userName)
        {
            var salas = CarregarSalas();
            var sala = salas.FirstOrDefault(s => s.RoomName == roomName);

            if (sala == null)
            {
                sala = new Sala { RoomName = roomName };
                salas.Add(sala);
            }

            if (!sala.Participantes.Contains(userName))
                sala.Participantes.Add(userName);

            SalvarSalas(salas);
        }

        public bool Participa(string roomName, string userName)
        {
            var sala = CarregarSalas().FirstOrDefault(s => s.RoomName == roomName);
            return sala != null && sala.Participantes.Contains(userName);
        }

        public List<Message> ObterHistorico(string roomName)
        {
            var sala = CarregarSalas().FirstOrDefault(s => s.RoomName == roomName);
            return sala?.Messages.OrderBy(m => m.SentAt).ToList() ?? new List<Message>();
        }

        public void SalvarMensagem(Message mensagem)
        {
            var salas = CarregarSalas();
            var sala = salas.FirstOrDefault(s => s.RoomName == mensagem.RoomName);

            if (sala == null)
            {
                sala = new Sala { RoomName = mensagem.RoomName };
                salas.Add(sala);
            }

            sala.Messages.Add(mensagem);

            if (!sala.Participantes.Contains(mensagem.UserName))
                sala.Participantes.Add(mensagem.UserName);

            SalvarSalas(salas);
        }
    }
}