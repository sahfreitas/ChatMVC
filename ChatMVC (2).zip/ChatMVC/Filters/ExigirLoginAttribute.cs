using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ChatMVC.Filters
{
    // Bloqueia o acesso a qualquer Action do controller/decorado com este
    // atributo caso não exista usuário logado na Session.
    // - Requisição normal (navegador pedindo uma página): redireciona pro Login.
    // - Requisição AJAX (ex.: fetch/XMLHttpRequest): responde 401, sem redirecionar,
    //   pra quem estiver consumindo a API poder tratar o erro.
    public class ExigirLoginAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var userName = context.HttpContext.Session.GetString("UserName");

            if (string.IsNullOrEmpty(userName))
            {
                var ehAjax = context.HttpContext.Request.Headers["X-Requested-With"] == "XMLHttpRequest";

                context.Result = ehAjax
                    ? new StatusCodeResult(StatusCodes.Status401Unauthorized)
                    : new RedirectToActionResult("Login", "Account", null);

                return;
            }

            base.OnActionExecuting(context);
        }
    }
}
