// Atualiza a tela da sala automaticamente para simular chat em tempo real
setInterval(() => {
    location.reload();
}, 5000);